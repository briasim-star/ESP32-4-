# PEMF Controller - one-time setup (no coding required)

This repo builds itself. Once it's on GitHub, GitHub's own servers compile
the firmware automatically every time the code changes, and publish a
one-click "Install" web page identical in spirit to the one you used before.
You never need Arduino IDE.

## One-time setup (about 10 minutes, all in your browser)

1. **Create a free GitHub account** at github.com, if you don't have one.
2. **Create a new repository**: click the `+` in the top right -> "New
   repository". Name it anything (e.g. `pemf-controller`). Leave it
   Public. Don't add a README/gitignore/license - leave it empty. Click
   "Create repository".
3. **Upload these files**: on the new repo's page, click "uploading an
   existing file". Drag the entire contents of this folder (the
   `PEMF_Controller`, `extras`, `docs`, and `.github` folders, all
   together) into the browser window. Chrome/Edge will preserve the
   folder structure. Click "Commit changes".
4. **Turn on GitHub Pages**: go to the repo's Settings tab -> Pages
   (left sidebar). Under "Build and deployment", set Source to
   "Deploy from a branch", Branch to `main`, folder to `/docs`. Click
   Save.
5. **Let it build**: click the "Actions" tab at the top of the repo.
   You should see a workflow run start automatically (it runs on every
   upload). Wait for the green checkmark - first run takes 3-6 minutes
   since it's installing the ESP32 compiler toolchain from scratch.
   If it fails (red X), click into it, copy the red error text, and
   send it to me - it's almost always a one-line fix.
6. **Find your install page**: back in Settings -> Pages, GitHub shows
   a URL like `https://yourusername.github.io/pemf-controller/`. Your
   install page is that URL + `install.html`.

## Every time after that

Whenever you want a change, tell me what you want, I'll hand you updated
files, you upload them the same way (step 3), and step 5 happens again
automatically. Nothing else changes.

## Flashing the board

1. Open your install page (from step 6 above) in **Chrome or Edge**
   (Web Serial doesn't work in Safari or Firefox).
2. **Now plug the ESP32 board into a USB port.**
3. Click "Install", pick the correct serial port when the browser asks,
   and wait for it to finish. Don't unplug during flashing.

That's the entire workflow - the same one-click flash experience as the
site you used before, just serving firmware I control instead of someone
else's project.
